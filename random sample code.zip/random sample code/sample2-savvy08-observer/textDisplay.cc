#include "textDisplay.h"
#include "cell.h"

TextDisplay::TextDisplay( int n ):
    dimension{n} {
    for ( int i = 0; i < dimension; i++ ) {
        std::vector<char> rowDisplay( dimension, '.');
        display.emplace_back(rowDisplay);
    }
}

//!!!!!
void TextDisplay::notified( Subject* whoNotified ) {
    auto currState = whoNotified->getState();
    display[currState[1]][currState[2]] = currState[0] == 1 ? '1' : '.';
}

std::ostream& operator<<( std::ostream& out, const TextDisplay& td) {
    for ( auto n : td.display ) {
        for ( auto m : n ) {
            out << m;
        }
        out << std::endl;
    }
    return out;
}