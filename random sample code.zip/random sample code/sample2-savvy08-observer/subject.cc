#include "subject.h" 
#include "observer.h"

// add new observers to vector
void Subject::attachOb( Observer* ob ) {
    neighbours.emplace_back(ob);
}

//!!!!!
// if subject changes, then subject need
// to notify all its observers
void Subject::notifyOb() {
    for ( auto ob : neighbours ) {
        ob->notified( this );
    }
}

Subject::~Subject() { }