#include "grid.h"
using namespace std;
int main() {
    Grid g;
    
    g.initGrid( 25 );
    cout << "generated matrix is as below: " << endl;
    cout << g << endl;

    g.countIsland();
}