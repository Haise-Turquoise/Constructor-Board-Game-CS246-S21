#include "cell.h" 
#include "subject.h"
#include "observer.h"

Cell::Cell(int val, int row, int col):
    val{val}, row{row}, col{col} {}

// used when Cell is treated as Subject
void Cell::eraseVal() {
    val = 0;
    notifyOb(); // notify all neighbor
}

// used when Cell is treated as Subject
std::vector<int> Cell::getState() const {
    return { val, row, col };
} 

//!!!!!
// used when Cell is treated as Observer
void Cell::notified( Subject* whoNotified ) {
    if ( val != 0 ) eraseVal();
}

