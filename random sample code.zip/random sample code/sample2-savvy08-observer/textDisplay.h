#ifndef __TEXTDISPLAY_H__
#define __TEXTDISPLAY_H__

#include <iostream>
#include <vector>
#include "observer.h" 
 
class Subject;

class TextDisplay: public Observer {
    int dimension; 
    std::vector<std::vector<char>> display; 

    public:
    TextDisplay( int ); 

    void notified( Subject* ) override; 

    friend std::ostream& operator<<( std::ostream&, const TextDisplay& );
}; 

std::ostream& operator<<( std::ostream&, const TextDisplay& );

#endif 