#ifndef __OBSERVER_H__
#define __OBSERVER_H__

class Subject; 
class Observer { 

    public: 
    virtual void notified( Subject* ) = 0; 
    virtual ~Observer(); 

};

#endif 
