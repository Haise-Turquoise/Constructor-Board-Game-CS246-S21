#ifndef __SUBJECT_H__
#define __SUBJECT_H__

#include <vector>
class Observer;  

class Subject {

    protected:
    std::vector<Observer*> neighbours; 

    public: 
    void attachOb( Observer* ); 

    void notifyOb();

    virtual std::vector<int> getState() const = 0; 

    virtual ~Subject(); 
};

#endif 