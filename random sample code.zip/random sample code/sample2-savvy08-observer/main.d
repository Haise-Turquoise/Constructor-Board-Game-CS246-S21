main.o: main.cc grid.h cell.h subject.h observer.h
