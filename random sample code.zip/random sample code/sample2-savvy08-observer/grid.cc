#include <random>
#include <chrono>
#include "grid.h"
#include "textDisplay.h"
using namespace std;
void Grid::initGrid( int n ) {
    dimension = n;
    numIslands = 0;
    td = new TextDisplay ( n );
    generateCells();
    cellAttachObservers();
}

void Grid::generateCells() {
    srand(std::chrono::system_clock::now().time_since_epoch().count());
    for ( int i = 0; i < dimension; i++ ) {
        std::vector<Cell> rowCells;
        for ( int j = 0; j < dimension; j++ ) {
            int val = rand() % 2;
            rowCells.emplace_back( val, i, j );
            td->notified( &rowCells.back() );
        }
        cells.emplace_back(rowCells);
    }
}


//!!!!!
void Grid::cellAttachObservers() {
    for ( int i = 0; i < dimension; i++ ) {
        for ( int j = 0; j < dimension; j++ ) {

            if ( i > 0 ) cells[i][j].attachOb( &cells[i-1][j] );

            if ( i < dimension - 1 ) cells[i][j].attachOb( &cells[i+1][j] );

            if ( j > 0 ) cells[i][j].attachOb( &cells[i][j-1] );

            if ( j < dimension - 1 ) cells[i][j].attachOb( &cells[i][j+1] );

            cells[i][j].attachOb(td);
        }
    }
}

Grid::~Grid() { delete td; }

std::ostream& operator<<( std::ostream& out, const Grid& g ) {
    out << *(g.td);
    return out;
}

void Grid::countIsland() {
    for ( int i = 0; i < dimension; i++ ) {
        for ( int j = 0; j < dimension; j++ ) {
            if ( cells[i][j].getState()[0] == 1 ) {
                numIslands += 1;
                cout << "Found " << numIslands << "islands" << endl;
                cells[i][j].eraseVal();
                cout << *td;
                cout << "Press Any key to continue: ";
                char key;
                cin >> key;
            }
        }
    }
    cout << "There are " << numIslands << " islands" << endl;
}