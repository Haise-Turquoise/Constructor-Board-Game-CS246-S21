#ifndef __GRID_H__
#define __GRID_H__
 
#include <iostream>
#include <vector>
#include "cell.h" 
#include "textdisplay.h"

class TextDisplay; 

class Grid {

    int dimension, numIslands; 
    std::vector<std::vector<Cell>> cells; 
    TextDisplay* td = nullptr; 

    void generateCells();
    void cellAttachObservers();
    
    public: 
    void initGrid( int ); 

    void countIsland(); 
    ~Grid(); 
    friend std::ostream& operator<<( std::ostream&, const Grid& );
};

std::ostream& operator<<( std::ostream&, const Grid& ); 
#endif 