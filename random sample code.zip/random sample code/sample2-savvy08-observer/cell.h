#ifndef __CELL_H__ 
#define __CELL_H__
 
#include <vector>
#include "subject.h"
#include "observer.h"

class Cell: public Subject, public Observer {
    int val, row, col; 

    public:
    Cell( int, int, int ); 

    void eraseVal(); 

    std::vector<int> getState() const override; 

    void notified( Subject* ) override; 
};

#endif 