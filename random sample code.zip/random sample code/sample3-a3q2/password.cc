#include "password.h"

// Do not modify these functions
char genCodeChar() {
	static std::default_random_engine gen;
	static std::uniform_int_distribution<int> dist(0,5);
	static bool flag = false;
	if (!flag) {
		gen.seed(SEED);
		flag = true;
	}
	char ret = 'A' + dist(gen);
	return ret;
}

void setPassword(char* password, int length) {
	for (int i=0; i<length; ++i) {
	char ind = genCodeChar();
	password[i]=pegs[ind-'A'];
	}
}
