#ifndef _PASSWORD_H_
#define _PASSWORD_H_
#include <string>
#include <random>

#define SEED 5

const char pegs[6] {'A','B','C','D','E','F'};

char genCodeChar();
void setPassword(char* password, int length);

#endif